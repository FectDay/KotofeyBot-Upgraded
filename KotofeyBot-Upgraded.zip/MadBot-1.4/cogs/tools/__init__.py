from classes.cooldown import default_cooldown, hard_cooldown
