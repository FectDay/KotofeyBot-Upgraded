# Based on https://github.com/boticord/boticordpy
# Boticord API submodule for MadBot.
from .client import BoticordClient
